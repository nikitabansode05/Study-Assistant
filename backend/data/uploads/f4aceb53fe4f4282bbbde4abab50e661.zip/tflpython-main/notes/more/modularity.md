

👨‍🏫 **Modularity and Inheritance:**

"Imagine you are building a big city. A city can’t be built with one giant building — it needs **different blocks**: schools, hospitals, offices, homes, parks.

Now think of your Python program as that city. If you try to put everything in one single `.py` file — all your functions, classes, constants — it’s like trying to build the entire city in one building. Messy, hard to manage, and impossible to expand.

That’s where **Modules** come in.
👉 A Python module is just a **separate `.py` file** that contains reusable code (functions, classes, variables).
👉 You can import this file into another Python script and use its features.
In short: A module is like a **city block** — focused, reusable, and well-organized."


📘 **Hands-On Example:**

1. Create a file `math_utils.py`

```python
# math_utils.py

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

PI = 3.14159
```

This is your **module**.


2. Now, create another file `main.py`

```python
# main.py

import math_utils   # importing the module

print("Addition:", math_utils.add(5, 3))
print("Subtraction:", math_utils.subtract(10, 4))
print("Value of PI:", math_utils.PI)
```

When you run `main.py`, it will use code from `math_utils.py`.
That’s like borrowing resources from another block in your city.


⚡ **Extra Magic with Modules:**

* Python already gives you many **built-in modules** (like `math`, `os`, `datetime`).
* Example:

```python
import math

print(math.sqrt(16))   # 4.0
print(math.factorial(5))  # 120
```

🎯 **Mentor’s Wisdom:**
"Think of modules as **toolkits**. You don’t need to rebuild a hammer every time you want to drive a nail — just reuse the toolkit. Similarly, don’t rewrite code — make modules, and import them wherever needed."


👨‍🏫 **HR Department:**

"Imagine your company just started a new **HR department**. The HR team wants to manage employees. But they don’t want to put all employee details in one file — that would be chaos.

So HR says:

* We’ll create a **base file** for common employee details (`Employee.py`).
* Then, for special types of employees, like Salespeople, we’ll extend it (`SalesEmployee.py`).

This is exactly how **modules with inheritance** work in Python."


📂 **Folder Structure (HR Module):**

```
HR/
│── __init__.py
│── Employee.py
│── SalesEmployee.py
```

* `__init__.py` → makes `HR` a **package**.
* `Employee.py` → base class.
* `SalesEmployee.py` → child class that inherits.



### 1️⃣ **Employee.py**

```python
# HR/Employee.py

class Employee:
    def __init__(self, emp_id, name, salary):
        self.emp_id = emp_id
        self.name = name
        self.salary = salary

    def get_details(self):
        return f"ID: {self.emp_id}, Name: {self.name}, Salary: {self.salary}"

    def calculate_annual_salary(self):
        return self.salary * 12
```



### 2️⃣ **SalesEmployee.py**

```python
# HR/SalesEmployee.py
from HR.Employee import Employee

class SalesEmployee(Employee):
    def __init__(self, emp_id, name, salary, sales_target, commission_rate):
        super().__init__(emp_id, name, salary)   # inherit from Employee
        self.sales_target = sales_target
        self.commission_rate = commission_rate

    def calculate_commission(self, sales_achieved):
        if sales_achieved >= self.sales_target:
            return sales_achieved * self.commission_rate
        return 0

    def get_details(self):
        base_details = super().get_details()
        return f"{base_details}, Sales Target: {self.sales_target}, Commission Rate: {self.commission_rate}"
```


### 3️⃣ **Main Program (test.py)**

```python
# test.py
from HR.Employee import Employee
from HR.SalesEmployee import SalesEmployee

# Normal employee
emp1 = Employee(101, "Ravi", 40000)
print(emp1.get_details())
print("Annual Salary:", emp1.calculate_annual_salary())

print("-----------")

# Sales employee
sales_emp = SalesEmployee(201, "Tejas", 30000, 500000, 0.05)
print(sales_emp.get_details())
print("Annual Salary:", sales_emp.calculate_annual_salary())
print("Commission Earned:", sales_emp.calculate_commission(600000))
```



✅ **Output:**

```
ID: 101, Name: Ravi, Salary: 40000
Annual Salary: 480000
-----------
ID: 201, Name: Tejas, Salary: 30000, Sales Target: 500000, Commission Rate: 0.05
Annual Salary: 360000
Commission Earned: 30000.0
```



🎯 **Mentor’s Closing Thought:**
"See how neat this looks?

* `Employee.py` holds common logic.
* `SalesEmployee.py` extends it with sales-specific behavior.
* Inheritance keeps your code DRY (Don’t Repeat Yourself).
* And because we used a **module/package structure**, it’s reusable in any project."




👨‍🏫 **Extemding Inheritance:**

"HR now says — we also have **Managers**. Managers are not like sales employees; they don’t earn commission, but they do get a **bonus** based on performance.

So just like we created `SalesEmployee` from `Employee`, we’ll now create a new module: `ManagerEmployee.py`.

This shows students how we can keep extending our HR module with new specialized roles, without touching the base `Employee.py`."


📂 **Updated Folder Structure**

```
HR/
│── __init__.py
│── Employee.py
│── SalesEmployee.py
│── ManagerEmployee.py
```


### 1️⃣ **ManagerEmployee.py**

```python
# HR/ManagerEmployee.py
from HR.Employee import Employee

class ManagerEmployee(Employee):
    def __init__(self, emp_id, name, salary, bonus_percentage):
        super().__init__(emp_id, name, salary)
        self.bonus_percentage = bonus_percentage

    def calculate_bonus(self):
        return self.salary * self.bonus_percentage

    def get_details(self):
        base_details = super().get_details()
        return f"{base_details}, Bonus Percentage: {self.bonus_percentage}"
```

### 2️⃣ **Updated Main Program (test.py)**

```python
# test.py
from HR.Employee import Employee
from HR.SalesEmployee import SalesEmployee
from HR.ManagerEmployee import ManagerEmployee

# Normal employee
emp1 = Employee(101, "Ravi", 40000)
print(emp1.get_details())
print("Annual Salary:", emp1.calculate_annual_salary())

print("-----------")

# Sales employee
sales_emp = SalesEmployee(201, "Tejas", 30000, 500000, 0.05)
print(sales_emp.get_details())
print("Annual Salary:", sales_emp.calculate_annual_salary())
print("Commission Earned:", sales_emp.calculate_commission(600000))

print("-----------")

# Manager employee
manager_emp = ManagerEmployee(301, "Anita", 60000, 0.1)
print(manager_emp.get_details())
print("Annual Salary:", manager_emp.calculate_annual_salary())
print("Bonus:", manager_emp.calculate_bonus())
```

✅ **Output:**

```
ID: 101, Name: Ravi, Salary: 40000
Annual Salary: 480000
-----------
ID: 201, Name: Tejas, Salary: 30000, Sales Target: 500000, Commission Rate: 0.05
Annual Salary: 360000
Commission Earned: 30000.0
-----------
ID: 301, Name: Anita, Salary: 60000, Bonus Percentage: 0.1
Annual Salary: 720000
Bonus: 6000.0
```


🎯 **Mentor’s Closing Wisdom:**
"Notice how flexible this design is?

* The **base Employee class** holds the essentials.
* Each specialized employee type (`SalesEmployee`, `ManagerEmployee`) extends it with their unique logic.
* Tomorrow, if HR says *we need Interns or Contract Employees*, you just add another module — no need to rewrite everything."


Excellent 🙌 Now we’ll go one step higher in the HR module story — introducing a **SalesManager** who is both a **Manager** and a **SalesEmployee**. This will let students see **multiple inheritance** in Python in action.


👨‍🏫 **Multiple Inheritance:**

"Now HR says — some managers also handle sales targets. They want the benefits of both:

* A manager’s **bonus**,
* A salesperson’s **commission**.

This is a real-world case for **multiple inheritance**. In Python, a class can inherit from more than one parent class. But we need to be careful — Python uses something called the **MRO (Method Resolution Order)** to decide which parent’s method to call when there’s a conflict."

📂 **Updated Folder Structure**

```
HR/
│── __init__.py
│── Employee.py
│── SalesEmployee.py
│── ManagerEmployee.py
│── SalesManager.py
```


### 1️⃣ **SalesManager.py**

```python
# HR/SalesManager.py
from HR.SalesEmployee import SalesEmployee
from HR.ManagerEmployee import ManagerEmployee

class SalesManager(SalesEmployee, ManagerEmployee):
    def __init__(self, emp_id, name, salary, sales_target, commission_rate, bonus_percentage):
        # Initialize using SalesEmployee constructor first (MRO order matters)
        SalesEmployee.__init__(self, emp_id, name, salary, sales_target, commission_rate)
        ManagerEmployee.__init__(self, emp_id, name, salary, bonus_percentage)

    def get_details(self):
        base_details = super().get_details()  # super() will follow MRO
        return f"{base_details}, (SalesManager Role)"
```


### 2️⃣ **Updated Main Program (test.py)**

```python
# test.py
from HR.Employee import Employee
from HR.SalesEmployee import SalesEmployee
from HR.ManagerEmployee import ManagerEmployee
from HR.SalesManager import SalesManager

# Normal employee
emp1 = Employee(101, "Ravi", 40000)
print(emp1.get_details())
print("Annual Salary:", emp1.calculate_annual_salary())

print("-----------")

# Sales employee
sales_emp = SalesEmployee(201, "Tejas", 30000, 500000, 0.05)
print(sales_emp.get_details())
print("Annual Salary:", sales_emp.calculate_annual_salary())
print("Commission Earned:", sales_emp.calculate_commission(600000))

print("-----------")

# Manager employee
manager_emp = ManagerEmployee(301, "Anita", 60000, 0.1)
print(manager_emp.get_details())
print("Annual Salary:", manager_emp.calculate_annual_salary())
print("Bonus:", manager_emp.calculate_bonus())

print("-----------")

# Sales Manager (Multiple Inheritance)
sales_manager = SalesManager(401, "Vikram", 80000, 1000000, 0.03, 0.15)
print(sales_manager.get_details())
print("Annual Salary:", sales_manager.calculate_annual_salary())
print("Commission Earned:", sales_manager.calculate_commission(1200000))
print("Bonus:", sales_manager.calculate_bonus())
```


✅ **Output:**

```
ID: 101, Name: Ravi, Salary: 40000
Annual Salary: 480000
-----------
ID: 201, Name: Tejas, Salary: 30000, Sales Target: 500000, Commission Rate: 0.05
Annual Salary: 360000
Commission Earned: 30000.0
-----------
ID: 301, Name: Anita, Salary: 60000, Bonus Percentage: 0.1
Annual Salary: 720000
Bonus: 6000.0
-----------
ID: 401, Name: Vikram, Salary: 80000, Sales Target: 1000000, Commission Rate: 0.03, Bonus Percentage: 0.15, (SalesManager Role)
Annual Salary: 960000
Commission Earned: 36000.0
Bonus: 12000.0
```



⚡ **Mentor’s Wisdom on Multiple Inheritance:**

* Python resolves method calls using **MRO (Method Resolution Order)**.
* In `SalesManager(SalesEmployee, ManagerEmployee)`, Python will look at `SalesEmployee` first, then `ManagerEmployee`.
* Always design carefully, otherwise multiple inheritance can cause **diamond problems** (confusion if two parent classes define the same method).


### **HR Module Class Hierarchy (UML-style)**

```
             Employee
             ┌───────┐
             │ emp_id│
             │ name  │
             │ salary│
             └───┬───┘
                 │
        ┌────────┴─────────┐
        │                  │
   SalesEmployee       ManagerEmployee
   ┌────────────┐      ┌──────────────┐
   │ sales_target│      │ bonus_percentage│
   │ commission_rate │  └──────────────┘
   └────────────┘
         │
         │
   SalesManager
   ┌────────────────────────────┐
   │ sales_target               │
   │ commission_rate            │
   │ bonus_percentage           │
   └────────────────────────────┘
```

---

### **Mentor’s Story to Explain the Diagram:**

1. **Employee** is the **base class** — all employees share `emp_id`, `name`, and `salary`.
2. **SalesEmployee** extends Employee — adds `sales_target` and `commission_rate`.
3. **ManagerEmployee** extends Employee — adds `bonus_percentage`.
4. **SalesManager** inherits from both SalesEmployee and ManagerEmployee — gets **commission** *and* **bonus**.

Think of it like building blocks:

* Employee = foundation
* SalesEmployee = adds sales powers
* ManagerEmployee = adds management powers
* SalesManager = combines both

Python uses **MRO** to decide which parent’s method is called first when both parents define the same method.

 